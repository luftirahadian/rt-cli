#!/bin/sh
### clish path
export LD_LIBRARY_PATH=/opt/rt/lib/
#export CLISH_PATH=/opt/rt/etc/clish
if [ `id -u` = 0 ] ; then
        cd /opt/
        /opt/rt/bin/clish -l -x /opt/rt/etc/clish-en
    else
        cd /tmp
        /opt/rt/bin/clish -l -x /opt/rt/etc/clish
fi
